/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Entidades;

/**
 *
 * @author Personal
 */
public class Ppal {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
